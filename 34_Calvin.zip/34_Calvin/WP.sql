-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 26, 2017 at 05:45 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `34_Calvin`
--

-- --------------------------------------------------------

--
-- Table structure for table `WP`
--

CREATE TABLE `WP` (
  `Sr` int(100) NOT NULL,
  `T_Name` varchar(100) NOT NULL,
  `Descp` varchar(1000) NOT NULL,
  `Rel` varchar(1000) NOT NULL,
  `App` varchar(1000) NOT NULL,
  `Covr` varchar(1000) NOT NULL,
  `Preq` varchar(10) NOT NULL,
  `Duration` int(2) NOT NULL,
  `Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `WP`
--

INSERT INTO `WP` (`Sr`, `T_Name`, `Descp`, `Rel`, `App`, `Covr`, `Preq`, `Duration`, `Name`) VALUES
(1, ' WEB DEVELOPMENT	 ', ' Covering evreything related web programming i.e..creating own web pages.	 ', ' Web Programming	 ', ' web programming is in demand,creativity using your skills	 ', ' html,css,bootstrap,xhtml,javascript,etc	 ', ' Ye', 40, ' Calvin Monteiro '),
(2, ' ORACLE ', ' database language ,creating own database using all types of schemas	 ', ' dbms,mysql,etc	 ', ' need of database in each and every sector.	 ', ' dml,ddl,dcl,triggers,views,etc	 ', ' Ye', 45, ' Sunny Nair '),
(3, ' android programming	 ', ' creating your apps ,publishing them on the play store,etc	 ', ' oobject oriented programming language,structured programming approach,data structure algorithm and ananlysis	 ', ' make your own apps and if good ,can work for many android realted companies	 ', ' javascript,java,.net,etc	 ', ' Yes ', 40, ' Franklin Felix ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `WP`
--
ALTER TABLE `WP`
  ADD PRIMARY KEY (`Sr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `WP`
--
ALTER TABLE `WP`
  MODIFY `Sr` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
