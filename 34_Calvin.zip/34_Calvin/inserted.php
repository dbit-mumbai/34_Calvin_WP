<?php
	$a1 = $_POST['titlename'];
	$a2 = $_POST['description'];
	$a3 = $_POST['relevance'];
	$a4 = $_POST['application'];
	$a5 = $_POST['topics'];
	$a6 = $_POST['prerequisite'];
	$a7 = $_POST['duration'];
    $a8 = $_POST['speakername'];

    mysql_connect("localhost","root","");
    mysql_select_db("34_Calvin") ;
    $select = "insert into WP(T_Name, Descp, Rel, App, Covr, Preq, Duration, Name) values (' ".$a1." ',' ".$a2." ',' ".$a3." ', ' ".$a4." ', ' ".$a5." ', ' ".$a6." ', ' ".$a7." ', ' ".$a8." ')";
    
    $sql=mysql_query($select);  
    print '<script type="text/javascript">';
    print 'alert("The data is inserted")';
    print '</script>';
    header('Location: /cal/form5.php');  
    mysql_close();
?>	

