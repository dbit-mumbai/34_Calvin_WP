


function validateForm() {
    var x = document.forms["form"]["titlename"].value;
    if (x == "") {
        alert("titlename must be filled out");
        return false;
    }
    else
	return true;
}

function validateForm() {
    var x = document.forms["form"]["description"].value;
    if (x == "") {
        alert("description must be filled out");
        return false;
    }
else
    return true;
}

function validateForm() {
    var x = document.forms["form"]["relevance"].value;
    if (x == "") {
        alert("relevant topics must be filled out");
        return false;
    }
else 
     return true;
}

function validateForm() {
    var x = document.forms["form"]["application"].value;
    if (x == "") {
        alert("application must be filled out");
        return false;
    }
else 
return true;

}

function validateForm() {
    var x = document.forms["form"]["topics"].value;
    if (x == "") {
        alert("topics to be covered must be filled out");
        return false;
    }
else
 return true;
}


function validateForm() {
    var x = document.forms["form"]["duration"].value;
    if (x == "") {
        alert("duration must be filled out");
        return false;
    }

else 
return true;
}

function validateForm() {
    var x = document.forms["form"]["speakername"].value;
    if (x == "") {
        alert("Name must be filled out");
        return false;
    }
else 
return true;
}

function validate(){
	var result=true;
	if(!validateForm())
		result=false;
	return result;
}






