<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="file.css">
<title>CSI</title>
</head>
<body>

<div class="plate">
  <img src="image1.png" align="left" style="width:100px;height:158px;"><img src="image2.jpg" align="right" style="width:100px;height:158px;">
  <p class="script"></p>
  <br>
  <p class="shadow text1">Computer Society Of India</p>
  <p class="shadow text1">D.B.I.T</p>
  <br>
  <p class="script"><span>Workshop/Seminar Details</span></p>
</div>
<?php
    $con = mysql_connect("localhost","root","");
    mysql_select_db("34_Calvin",$con);
    $sql = "SELECT * FROM WP";
    $myData = mysql_query($sql,$con);
    echo "<table>
    <tr>
    <th>Title name</th>
    <th>Description</th>
    <th>Relevance to any subject<br> in Engineering curriculum</th>
    <th>Application/Industry demand</th>
    <th>Topics to be covered</th>
    <th>Pre-requisite Test Required</th>
    <th>Duration</th>
    <th>Speaker Name</th>
    </tr>";
    while ($record = mysql_fetch_array($myData)) {
      echo "<tr>";
      echo"<td>".$record['T_Name']."</td>";
      echo"<td>".$record['Descp']."</td>";
      echo"<td>".$record['Rel']."</td>";
      echo"<td>".$record['App']."</td>";
      echo"<td>".$record['Covr']."</td>";
      echo"<td>".$record['Preq']."  </td>";
      echo"<td>".$record['Duration']."</td>";
      echo"<td>".$record['Name']."</td>";
      echo "</tr>"; 
    }
    echo "</table>";
    mysql_close($con)
  ?>

</body>
</html>
